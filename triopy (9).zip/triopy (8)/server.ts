import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import Razorpay from "razorpay";
import * as admin from "firebase-admin";
import { getFirestore, Timestamp } from "firebase-admin/firestore";
import nodemailer from "nodemailer";

import firebaseConfig from "./firebase-applet-config.json";

dotenv.config();

// Temporary store for OTP verification codes
const otpStore = new Map<string, { code: string; expiresAt: number }>();


let firestoreDb: ReturnType<typeof getFirestore> | null = null;

function getAdminDb() {
  if (!firestoreDb) {
    try {
      if ((admin as any).apps.length === 0) {
        admin.initializeApp({
          projectId: firebaseConfig.projectId,
        });
      }
      firestoreDb = getFirestore();
    } catch (error) {
      console.error("Failed to initialize Firebase Admin SDK:", error);
      throw error;
    }
  }
  return firestoreDb;
}

const getRazorpayInstance = async () => {
  const db = getAdminDb();
  const configSnap = await db.collection('config').doc('payment').get();
  const config = configSnap.data();
  if (!config) throw new Error('Razorpay configuration not found');
  return new Razorpay({
    key_id: config.keyId,
    key_secret: config.keySecret,
  });
};

let aiInstance: GoogleGenAI | null = null;
function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.post("/api/send-otp", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email || !email.includes("@")) {
        return res.status(400).json({ error: "Invalid email address" });
      }

      // Generate 6-digit OTP
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes expiry

      otpStore.set(email.toLowerCase().trim(), { code: otpCode, expiresAt });

      const smtpUser = process.env.SMTP_USER;
      const smtpPass = process.env.SMTP_PASS;
      const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
      const smtpPort = parseInt(process.env.SMTP_PORT || "587");

      let sentRealEmail = false;

      if (smtpUser && smtpPass) {
        try {
          const transporter = nodemailer.createTransport({
            host: smtpHost,
            port: smtpPort,
            secure: smtpPort === 465,
            auth: {
              user: smtpUser,
              pass: smtpPass,
            },
          });

          await transporter.sendMail({
            from: `"TRIOPY Support" <${smtpUser}>`,
            to: email,
            subject: "Your TRIOPY Verification Code",
            text: `Your TRIOPY verification code is: ${otpCode}. It is valid for 10 minutes.`,
            html: `
              <div style="font-family: 'Inter', sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background-color: #ffffff;">
                <h2 style="color: #4f46e5; font-size: 24px; text-align: center; margin-bottom: 20px; font-weight: bold;">TRIOPY</h2>
                <p style="font-size: 16px; color: #1e293b;">Hello,</p>
                <p style="font-size: 16px; color: #334155;">You requested a verification code to complete your registration on TRIOPY. Please use the following One-Time Password (OTP):</p>
                <div style="background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #4f46e5; border-radius: 8px; margin: 25px 0;">
                  ${otpCode}
                </div>
                <p style="color: #64748b; font-size: 14px; line-height: 1.5;">This code is valid for 10 minutes. If you did not make this request, you can safely ignore this email.</p>
                <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
                <p style="color: #94a3b8; font-size: 12px; text-align: center; margin: 0;">TRIOPY - Your Smart Study & Fitness Companion</p>
              </div>
            `,
          });
          sentRealEmail = true;
          console.log(`[OTP] Successfully sent real email OTP to ${email}`);
        } catch (emailError: any) {
          console.error("Failed to send real email via SMTP:", emailError);
          return res.status(500).json({ 
            error: `Gmail/SMTP delivery failed: ${emailError.message || emailError}. Please verify your SMTP settings and that you are using a 16-character App Password, not your account login password.` 
          });
        }
      }

      // Always log to server console for easy troubleshooting in dev environments
      console.log(`\n========================================\n[OTP DEBUG LOG]\nEmail: ${email}\nOTP Code: ${otpCode}\n========================================\n`);

      res.json({
        success: true,
        message: sentRealEmail ? "OTP sent to your email address." : "OTP generated and logged (SMTP not configured).",
        debugOtp: sentRealEmail ? null : otpCode
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to generate/send OTP" });
    }
  });

  app.post("/api/verify-otp", async (req, res) => {
    try {
      const { email, code } = req.body;
      if (!email || !code) {
        return res.status(400).json({ error: "Email and OTP code are required" });
      }

      const key = email.toLowerCase().trim();
      const stored = otpStore.get(key);

      if (!stored) {
        return res.status(400).json({ error: "No OTP sent to this email or it has expired" });
      }

      if (Date.now() > stored.expiresAt) {
        otpStore.delete(key);
        return res.status(400).json({ error: "OTP has expired" });
      }

      if (stored.code !== code.trim()) {
        return res.status(400).json({ error: "Incorrect OTP code" });
      }

      // OTP is valid!
      otpStore.delete(key);
      res.json({ success: true, message: "Email verified successfully" });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to verify OTP" });
    }
  });

  app.post("/api/create-order", async (req, res) => {
    try {
      const razorpay = await getRazorpayInstance();
      const { amount, currency } = req.body;
      const order = await razorpay.orders.create({
        amount: amount * 100, // paise
        currency: currency,
        receipt: "receipt_" + Date.now(),
      });
      res.json(order);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.post("/api/verify-payment", async (req, res) => {
    try {
      const { userId, subscriptionType } = req.body;
      
      const db = getAdminDb();
      const subRef = db.collection('users').doc(userId).collection('subscription').doc('status');
      
      let durationDays = 30; // Default monthly
      if (subscriptionType.includes('yearly')) {
        durationDays = 365;
      }
      
      await subRef.set({
        isPremium: true,
        subscriptionType: subscriptionType,
        subscriptionEndDate: Timestamp.fromDate(new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000))
      }, { merge: true });
      
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to verify payment" });
    }
  });

  app.get("/api/quote", async (req, res) => {
    try {
      const ai = getAI();
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: "Provide a short, inspirational, health/fitness or study related quote for today.",
      });
      res.json({ quote: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch quote" });
    }
  });

  app.post("/api/suggest-schedule", async (req, res) => {
    try {
      const { journalEntries } = req.body;
      const prompt = `Analyze the following daily journal notes and suggest an optimized daily schedule for fitness and study tasks:\n\n${journalEntries.map((e: any) => `- ${e.note}`).join('\n')}`;
      
      const ai = getAI();
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });
      res.json({ schedule: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to generate schedule" });
    }
  });

  app.post("/api/generate-weekly-summary", async (req, res) => {
    try {
      const { stats, goals, quests } = req.body;
      const prompt = `Generate a friendly, encouraging weekly summary email based on the following user data:
      - Total XP: ${stats.totalXP}
      - Goals: ${JSON.stringify(goals)}
      - Quests completed this week: ${quests.length}
      
      Format the email to be engaging and motivating.`;
      
      const ai = getAI();
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });
      res.json({ summary: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to generate summary" });
    }
  });

  app.post("/api/food-recognition", async (req, res) => {
    try {
      const { image } = req.body;
      const ai = getAI();
      const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
      
      const prompt = `Analyze this image of food and identify the dishes.
      Estimate the nutritional values:
      - Calories (kcal)
      - Protein (g)
      - Carbs (g)
      - Fat (g)
      - Fiber (g)
      - Sugar (g)
      Provide your confidence score (0 to 1).
      Format your response STRICTLY as a JSON object of this structure:
      {
        "name": "Identified Food Name",
        "calories": 350,
        "protein": 12,
        "carbs": 45,
        "fat": 10,
        "fiber": 4,
        "sugar": 8,
        "confidence": 0.92
      }`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Data
            }
          },
          prompt
        ],
        config: {
          responseMimeType: "application/json"
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to process food recognition" });
    }
  });

  app.post("/api/notes-scanner", async (req, res) => {
    try {
      const { image } = req.body;
      const ai = getAI();
      const base64Data = image.replace(/^data:image\/\w+;base64,/, "");

      const prompt = `Extract all text and key concepts from these handwritten or printed notes.
      Return a structured markdown text. Be precise and capture formulas, lists, or headers cleanly.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Data
            }
          },
          prompt
        ]
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to scan notes" });
    }
  });

  app.post("/api/homework-ai", async (req, res) => {
    try {
      const { image, questionText } = req.body;
      const ai = getAI();
      
      let contents: any[] = [];
      if (image) {
        const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
        contents.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Data
          }
        });
      }

      const prompt = `Analyze this question: "${questionText || 'Look at the image question'}"
      Provide:
      1. A detailed step-by-step explanation.
      2. The final answer.
      3. Three practice questions with similar concept to reinforce learning.
      
      Format the output in a structured, friendly markdown format.`;
      contents.push(prompt);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents
      });

      res.json({ explanation: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to solve homework question" });
    }
  });

  app.post("/api/body-measurement", async (req, res) => {
    try {
      const { height, weight, gender, age, image } = req.body;
      const ai = getAI();

      let contents: any[] = [];
      if (image) {
        const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
        contents.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Data
          }
        });
      }

      const prompt = `Analyze this person's body shape and proportions (height: ${height} cm, weight: ${weight} kg, gender: ${gender}, age: ${age}).
      Estimate the following measurements (in cm) and parameters:
      - Waist circumference
      - Chest circumference
      - Shoulder width
      - Hip circumference
      - Estimated body fat (%)
      - BMI
      
      Format your response strictly as a JSON object:
      {
        "waist": 82,
        "chest": 98,
        "shoulder": 44,
        "hip": 96,
        "bodyFat": 18.5,
        "bmi": 22.4,
        "tips": "Your BMI is in the healthy range. Continue with standard resistance training."
      }`;
      contents.push(prompt);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          responseMimeType: "application/json"
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to estimate body measurements" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
