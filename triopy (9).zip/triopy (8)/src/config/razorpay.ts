export const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || '';
export const RAZORPAY_SECRET = process.env.RAZORPAY_SECRET || '';
