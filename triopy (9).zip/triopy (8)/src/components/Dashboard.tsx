import React from 'react';
import { useFirebase } from './FirebaseProvider';
import { HealthModule } from './health/HealthModule';
import { FitnessModule } from './fitness/FitnessModule';
import { StudyModule } from './study/StudyModule';
import { PremiumGuard } from './PremiumGuard';
import { DailyMotivation } from './DailyMotivation';
import { DailyQuests } from './gamification/DailyQuests';
import { HealthJournal } from './journal/HealthJournal';
import { QuestTrends } from './gamification/QuestTrends';
import { Badges } from './gamification/Badges';
import { CommunityLeaderboard } from './gamification/CommunityLeaderboard';
import { GoalTracker } from './goals/GoalTracker';
import { StreakCounter } from './gamification/StreakCounter';
import { ChallengeRoom } from './gamification/ChallengeRoom';
import { DailyHabits } from './habits/DailyHabits';
import { HabitTrendChart } from './habits/HabitTrendChart';
import { WaterTracker } from './health/WaterTracker';
import { DataExport } from './DataExport';
import { SmartScheduler } from './goals/SmartScheduler';
import { ThemeSwitcher } from './ThemeSwitcher';
import { SpeechReminder } from './SpeechReminder';
import { useHabits } from '../hooks/useHabits';

import { LifeScore } from './LifeScore';
import { AIChallengeEngine } from './AIChallengeEngine';
import { FriendChallenges } from './FriendChallenges';
import { RealTimeCameraAI } from './RealTimeCameraAI';

export const Dashboard: React.FC = () => {
  const { user } = useFirebase();
  const { habits } = useHabits();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 transition-colors">
      <header className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Hello, {user?.email}</h1>
          <p className="text-gray-600 dark:text-gray-400">Welcome back to Triopy.</p>
        </div>
        <div className="flex gap-2 items-center">
          <SpeechReminder />
          <ThemeSwitcher />
        </div>
      </header>
      
      <DailyMotivation />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Premium Status</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Active Pro Account</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Live Health Engine</h2>
          <p className="text-sm text-emerald-600 font-bold dark:text-emerald-400">Synced & Active</p>
        </div>
        <StreakCounter />
      </div>

      <div className="space-y-6">
        {/* Core Life Score and Live Posture / Scan AI */}
        <LifeScore />
        <RealTimeCameraAI />

        {/* AI Challenges & Friends Competitions */}
        <AIChallengeEngine />
        <FriendChallenges />

        {/* Standard Analytics & Logs */}
        <HabitTrendChart habits={habits} />
        <WaterTracker />
        <DailyHabits />
        <ChallengeRoom />
        <DataExport />
        <SmartScheduler />
        <GoalTracker />
        <Badges />
        <CommunityLeaderboard />
        <HealthJournal />
        <QuestTrends />
        <DailyQuests />
        <PremiumGuard requiredType="health"><HealthModule /></PremiumGuard>
        <PremiumGuard requiredType="fitness"><FitnessModule /></PremiumGuard>
        <PremiumGuard requiredType="study"><StudyModule /></PremiumGuard>
      </div>
    </div>
  );
};
