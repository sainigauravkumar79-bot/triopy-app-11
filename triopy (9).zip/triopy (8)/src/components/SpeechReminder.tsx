import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useFirebase } from './FirebaseProvider';

export const SpeechReminder: React.FC = () => {
  const { user } = useFirebase();
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    if (!enabled || !user) return;

    const checkSchedule = async () => {
      const now = new Date();
      const tenMinutesFromNow = new Date(now.getTime() + 10 * 60000);

      const schedulesRef = collection(db, 'users', user.uid, 'schedules');
      const q = query(schedulesRef, where('time', '>=', Timestamp.fromDate(now)), where('time', '<=', Timestamp.fromDate(tenMinutesFromNow)));
      
      const snapshot = await getDocs(q);
      snapshot.forEach(doc => {
        const data = doc.data();
        const utterance = new SpeechSynthesisUtterance(`Reminder: You have a scheduled session for ${data.title} in a few minutes. You got this!`);
        window.speechSynthesis.speak(utterance);
      });
    };

    const interval = setInterval(checkSchedule, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [enabled, user]);

  return (
    <button
      onClick={() => setEnabled(!enabled)}
      className={`p-2 rounded-full ${enabled ? 'bg-purple-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-500'}`}
      title={enabled ? "Disable verbal reminders" : "Enable verbal reminders"}
    >
      {enabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
    </button>
  );
};
