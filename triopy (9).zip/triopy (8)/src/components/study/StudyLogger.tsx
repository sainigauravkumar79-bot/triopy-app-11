import React, { useState } from 'react';
import { BookOpen } from 'lucide-react';

export const StudyLogger: React.FC = () => {
  const [subject, setSubject] = useState('');

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <BookOpen className="text-teal-600" />
        <h3 className="text-lg font-semibold text-gray-900">Study Logger</h3>
      </div>
      <input 
        type="text" 
        placeholder="Subject name" 
        value={subject} 
        onChange={(e) => setSubject(e.target.value)} 
        className="w-full p-3 border rounded-xl mb-3"
      />
      <button className="w-full py-3 bg-teal-600 text-white rounded-xl font-semibold">Log Session</button>
    </div>
  );
};
