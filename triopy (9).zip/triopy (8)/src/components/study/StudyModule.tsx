import React, { useState } from 'react';
import { PomodoroTimer } from './PomodoroTimer';
import { StudyLogger } from './StudyLogger';
import { FocusPlaylist } from './FocusPlaylist';
import { FocusHistory } from './FocusHistory';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

export const StudyModule: React.FC = () => {
  const { user } = useFirebase();
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const handleSessionComplete = async (duration: number) => {
    if (!user) return;
    try {
      const sessionsRef = collection(db, 'users', user.uid, 'studySessions');
      await addDoc(sessionsRef, {
        subject: 'General Study', // Could be enhanced to use current active subject
        duration,
        timestamp: Timestamp.now()
      });
      alert('Study session logged!');
    } catch (error) {
      console.error("Error logging session:", error);
    }
  };

  return (
    <div className="space-y-6">
      <button 
        onClick={() => setIsHistoryOpen(true)}
        className="text-sm text-purple-600 font-medium hover:underline"
      >
        View Study History
      </button>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PomodoroTimer onComplete={handleSessionComplete} />
        <StudyLogger />
        <FocusPlaylist />
      </div>
      <FocusHistory isOpen={isHistoryOpen} onClose={() => setIsHistoryOpen(false)} />
    </div>
  );
};
