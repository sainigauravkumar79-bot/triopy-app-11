import React, { useEffect, useState } from 'react';
import { Award } from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

const BADGES = [
  { name: 'Novice', xp: 100 },
  { name: 'Apprentice', xp: 500 },
  { name: 'Master', xp: 1000 },
];

export const Badges: React.FC = () => {
  const { user } = useFirebase();
  const [totalXP, setTotalXP] = useState(0);

  useEffect(() => {
    if (!user) return;
    const unsubscribe = onSnapshot(doc(db, 'users', user.uid, 'stats', 'main'), (doc) => {
      if (doc.exists()) {
        setTotalXP(doc.data().totalXP);
      }
    });
    return unsubscribe;
  }, [user]);

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Award className="text-purple-500" />
        <h3 className="text-lg font-semibold text-gray-900">Achievements</h3>
      </div>
      <div className="flex gap-2">
        {BADGES.map(badge => (
          <div key={badge.name} className={`p-2 rounded-lg text-xs font-bold ${totalXP >= badge.xp ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-400'}`}>
            {badge.name} ({badge.xp} XP)
          </div>
        ))}
      </div>
    </div>
  );
};
