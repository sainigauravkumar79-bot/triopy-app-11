import React, { useEffect, useState } from 'react';
import { Users } from 'lucide-react';
import { collectionGroup, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

interface LeaderboardEntry {
  userId: string;
  totalXP: number;
}

export const CommunityLeaderboard: React.FC = () => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    // Queries all 'stats' collections across the database
    const q = query(collectionGroup(db, 'stats'), orderBy('totalXP', 'desc'), limit(10));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({
        userId: doc.id,
        ...doc.data()
      } as LeaderboardEntry)));
    });

    return unsubscribe;
  }, []);

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Users className="text-indigo-500" />
        <h3 className="text-lg font-semibold text-gray-900">Community Leaderboard</h3>
      </div>
      <div className="space-y-2">
        {entries.map((entry, index) => (
          <div key={entry.userId} className="flex justify-between p-2 rounded-lg bg-gray-50 text-sm">
            <span>{index + 1}. User {entry.userId.slice(0, 5)}...</span>
            <span className="font-bold">{entry.totalXP} XP</span>
          </div>
        ))}
      </div>
    </div>
  );
};
