import React, { useEffect, useState } from 'react';
import { Flame } from 'lucide-react';
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

export const StreakCounter: React.FC = () => {
  const { user } = useFirebase();
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    if (!user) return;

    const calculateStreak = async () => {
      const questsRef = collection(db, 'users', user.uid, 'quests');
      const q = query(questsRef, where('completed', '==', true));
      const snapshot = await getDocs(q);
      
      const completedDates = new Set<string>();
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (data.completedAt) {
          const date = data.completedAt.toDate().toISOString().split('T')[0];
          completedDates.add(date);
        }
      });

      const sortedDates = Array.from(completedDates).sort().reverse();
      let currentStreak = 0;
      let checkDate = new Date();
      checkDate.setHours(0, 0, 0, 0);

      // Check if today or yesterday was the last activity to start counting
      const todayStr = checkDate.toISOString().split('T')[0];
      const yesterday = new Date(checkDate);
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (!sortedDates.includes(todayStr) && !sortedDates.includes(yesterdayStr)) {
        setStreak(0);
        return;
      }

      for (let i = 0; i < sortedDates.length; i++) {
        const dateStr = sortedDates[i];
        const date = new Date(dateStr);
        const expectedDate = new Date(checkDate);
        expectedDate.setDate(expectedDate.getDate() - i);
        
        if (dateStr === expectedDate.toISOString().split('T')[0]) {
          currentStreak++;
        } else {
          break;
        }
      }
      setStreak(currentStreak);
    };

    calculateStreak();
  }, [user]);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center gap-4">
      <div className="p-3 bg-orange-100 dark:bg-orange-900 rounded-2xl">
        <Flame className="text-orange-500" />
      </div>
      <div>
        <h3 className="text-sm text-gray-500 dark:text-gray-400">Current Streak</h3>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{streak} days</p>
      </div>
    </div>
  );
};
