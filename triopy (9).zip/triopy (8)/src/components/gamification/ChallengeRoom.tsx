import React, { useState, useEffect } from 'react';
import { Users, Trophy, Plus, X } from 'lucide-react';
import { collection, addDoc, query, where, getDocs, doc, updateDoc, arrayUnion, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

interface Room {
  id: string;
  name: string;
  creatorId: string;
  members: string[];
}

export const ChallengeRoom: React.FC = () => {
  const { user } = useFirebase();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [roomName, setRoomName] = useState('');

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'challengeRooms'), where('members', 'array-contains', user.uid));
    return onSnapshot(q, (snapshot) => {
      setRooms(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Room)));
    });
  }, [user]);

  const createRoom = async () => {
    if (!user || !roomName) return;
    await addDoc(collection(db, 'challengeRooms'), {
      name: roomName,
      creatorId: user.uid,
      members: [user.uid]
    });
    setRoomName('');
    setIsCreating(false);
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Users className="text-indigo-600" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Challenge Rooms</h3>
        </div>
        <button onClick={() => setIsCreating(true)} className="p-2 bg-indigo-100 dark:bg-indigo-900 text-indigo-600 rounded-full">
          <Plus size={20} />
        </button>
      </div>
      
      {isCreating && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl w-full max-w-sm">
            <h4 className="text-lg font-semibold mb-4">Create Room</h4>
            <input 
              value={roomName} onChange={(e) => setRoomName(e.target.value)}
              placeholder="Room Name" className="w-full p-3 rounded-xl border mb-4"
            />
            <div className="flex gap-2">
              <button onClick={() => setIsCreating(false)} className="flex-1 p-3 bg-gray-100 rounded-xl">Cancel</button>
              <button onClick={createRoom} className="flex-1 p-3 bg-indigo-600 text-white rounded-xl">Create</button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {rooms.map(room => (
          <div key={room.id} className="p-4 rounded-xl bg-gray-50 dark:bg-gray-700 flex justify-between items-center">
            <span className="font-medium text-gray-800 dark:text-white">{room.name}</span>
            <Trophy size={18} className="text-indigo-500" />
          </div>
        ))}
      </div>
    </div>
  );
};
