import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

export const QuestTrends: React.FC = () => {
  const { user } = useFirebase();
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    const fetchTrends = async () => {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      
      const questsRef = collection(db, 'users', user.uid, 'quests');
      // NOTE: This query requires an index on completedAt. 
      // Firestore will provide a link in the console error to create it if missing.
      const q = query(questsRef, where('completedAt', '>=', Timestamp.fromDate(oneWeekAgo)));
      
      const querySnapshot = await getDocs(q);
      
      // Process data to count completions per day
      const counts: Record<string, number> = {};
      querySnapshot.forEach(doc => {
        const data = doc.data();
        if (data.completedAt) {
          const date = data.completedAt.toDate().toLocaleDateString();
          counts[date] = (counts[date] || 0) + 1;
        }
      });
      
      // Convert to recharts format
      const chartData = Object.keys(counts).map(date => ({
        date,
        completions: counts[date]
      }));
      setData(chartData);
    };
    
    fetchTrends();
  }, [user]);

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Quest Completion Trend (Last 7 Days)</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Line type="monotone" dataKey="completions" stroke="#4f46e5" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
