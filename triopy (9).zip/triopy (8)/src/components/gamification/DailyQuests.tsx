import React, { useEffect, useState } from 'react';
import { Trophy, CheckCircle, Circle } from 'lucide-react';
import { collection, onSnapshot, doc, updateDoc, Timestamp, getDoc, setDoc, runTransaction, addDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

interface Quest {
  id: string;
  title: string;
  xp: number;
  completed: boolean;
}

export const DailyQuests: React.FC = () => {
  const { user } = useFirebase();
  const [quests, setQuests] = useState<Quest[]>([]);

  useEffect(() => {
    if (!user) return;

    const questsRef = collection(db, 'users', user.uid, 'quests');
    
    // Simple check/setup - in a real app, you'd have a separate mechanism for daily resets
    const unsubscribe = onSnapshot(questsRef, (snapshot) => {
      const questsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Quest));
      
      if (questsData.length === 0) {
        // Initial setup for example
        addDoc(questsRef, { title: 'Complete a study session', xp: 50, completed: false });
        addDoc(questsRef, { title: 'Drink 2L water', xp: 30, completed: false });
      } else {
        setQuests(questsData);
      }
    });

    return unsubscribe;
  }, [user]);

  const toggleQuest = async (quest: Quest) => {
    if (!user) return;
    
    const questRef = doc(db, 'users', user.uid, 'quests', quest.id);
    const statsRef = doc(db, 'users', user.uid, 'stats', 'main');

    await runTransaction(db, async (transaction) => {
      const questDoc = await transaction.get(questRef);
      if (!questDoc.exists()) return;
      
      const statsDoc = await transaction.get(statsRef);
      const currentXP = statsDoc.exists() ? statsDoc.data().totalXP : 0;
      
      const newCompleted = !quest.completed;
      const xpChange = newCompleted ? quest.xp : -quest.xp;
      
      transaction.update(questRef, {
        completed: newCompleted,
        completedAt: newCompleted ? Timestamp.now() : null
      });

      if (!statsDoc.exists()) {
        transaction.set(statsRef, { userId: user.uid, totalXP: Math.max(0, xpChange) });
      } else {
        transaction.update(statsRef, { totalXP: Math.max(0, currentXP + xpChange) });
      }
    });
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Trophy className="text-yellow-500" />
        <h3 className="text-lg font-semibold text-gray-900">Daily Quests</h3>
      </div>
      <div className="space-y-3">
        {quests.map(quest => (
          <div key={quest.id} className="flex items-center justify-between p-3 border rounded-xl">
            <span>{quest.title} (+{quest.xp} XP)</span>
            <button onClick={() => toggleQuest(quest)}>
              {quest.completed ? <CheckCircle className="text-green-500" /> : <Circle className="text-gray-300" />}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
