import React, { useState } from 'react';
import { Brain, Sparkles } from 'lucide-react';
import { collection, query, orderBy, getDocs, limit, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

interface JournalEntry {
  note: string;
  timestamp: Timestamp;
}

export const SmartScheduler: React.FC = () => {
  const { user } = useFirebase();
  const [schedule, setSchedule] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const generateSchedule = async () => {
    if (!user) return;
    setLoading(true);
    
    try {
      const q = query(collection(db, 'users', user.uid, 'journalEntries'), orderBy('timestamp', 'desc'), limit(5));
      const snapshot = await getDocs(q);
      const journalEntries = snapshot.docs.map(doc => doc.data() as JournalEntry);
      
      const response = await fetch('/api/suggest-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ journalEntries })
      });
      
      const data = await response.json();
      setSchedule(data.schedule);
    } catch (error) {
      console.error(error);
      alert('Failed to generate schedule.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Brain className="text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900">Smart Scheduler</h3>
      </div>
      
      <button 
        onClick={generateSchedule} 
        disabled={loading}
        className="w-full p-3 bg-purple-600 text-white rounded-xl flex items-center justify-center gap-2 mb-4 hover:bg-purple-700 disabled:opacity-50"
      >
        <Sparkles size={18} />
        {loading ? 'Analyzing...' : 'Suggest Optimized Schedule'}
      </button>

      {schedule && (
        <div className="p-4 bg-purple-50 rounded-lg text-sm text-purple-900 whitespace-pre-line">
          {schedule}
        </div>
      )}
    </div>
  );
};
