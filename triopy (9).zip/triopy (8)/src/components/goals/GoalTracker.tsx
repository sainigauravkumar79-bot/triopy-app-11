import React, { useEffect, useState } from 'react';
import { Target, TrendingUp } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

interface Goal {
  target: number;
}

export const GoalTracker: React.FC = () => {
  const { user } = useFirebase();
  const [goal, setGoal] = useState<number>(0);
  const [current, setCurrent] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const tsOneWeekAgo = Timestamp.fromDate(oneWeekAgo);

    const fetchData = async () => {
      // Fetch study sessions count for "study" type goal
      const studySessionsRef = collection(db, 'users', user.uid, 'studySessions');
      const studyQuery = query(studySessionsRef, where('timestamp', '>=', tsOneWeekAgo));
      const studySnapshot = await getDocs(studyQuery);
      
      setCurrent(studySnapshot.size);
      
      const goalRef = doc(db, 'users', user.uid, 'goals', 'study');
      const goalSnap = await getDocs(query(collection(db, 'users', user.uid, 'goals'), where('type', '==', 'study')));
      
      if (!goalSnap.empty) {
        setGoal(goalSnap.docs[0].data().target);
      }
      setLoading(false);
    };
    
    fetchData();
  }, [user]);

  const updateGoal = async (newTarget: number) => {
    if (!user) return;
    const goalRef = doc(db, 'users', user.uid, 'goals', 'study');
    await setDoc(goalRef, { userId: user.uid, type: 'study', target: newTarget });
    setGoal(newTarget);
  };

  const progress = goal > 0 ? Math.min((current / goal) * 100, 100) : 0;

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Target className="text-emerald-500" />
        <h3 className="text-lg font-semibold text-gray-900">Weekly Study Goal</h3>
      </div>
      
      <div className="mb-4">
        <label className="text-sm text-gray-500">Target sessions:</label>
        <input 
          type="number" 
          value={goal} 
          onChange={(e) => updateGoal(parseInt(e.target.value) || 0)} 
          className="w-full p-2 border rounded-lg"
        />
      </div>

      <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
        <div className="bg-emerald-500 h-4 rounded-full" style={{ width: `${progress}%` }}></div>
      </div>
      <p className="text-sm text-gray-600">{current} / {goal} sessions</p>
    </div>
  );
};
