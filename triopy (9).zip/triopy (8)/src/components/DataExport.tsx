import React, { useState } from 'react';
import { Download } from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useFirebase } from './FirebaseProvider';

export const DataExport: React.FC = () => {
  const { user } = useFirebase();
  const [loading, setLoading] = useState(false);

  const exportData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const collections = ['journalEntries', 'studySessions', 'quests', 'goals'];
      const data: any = {};
      
      for (const colName of collections) {
        const snap = await getDocs(collection(db, 'users', user.uid, colName));
        data[colName] = snap.docs.map(doc => doc.data());
      }
      
      const statsSnap = await getDocs(collection(db, 'users', user.uid, 'stats'));
      data['stats'] = statsSnap.docs.map(doc => doc.data());

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `user_data_${new Date().toISOString()}.json`;
      a.click();
    } catch (e) {
      console.error(e);
      alert('Failed to export data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <button 
      onClick={exportData} 
      disabled={loading} 
      className="flex items-center gap-2 p-3 bg-gray-900 text-white rounded-xl shadow-sm hover:bg-gray-800 disabled:opacity-50"
    >
      <Download size={18} />
      {loading ? 'Exporting...' : 'Export Progress Data (JSON)'}
    </button>
  );
};
