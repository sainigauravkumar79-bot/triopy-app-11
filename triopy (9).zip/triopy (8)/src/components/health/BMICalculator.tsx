import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

export const BMICalculator: React.FC = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);

  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100;
    if (w > 0 && h > 0) {
      setBmi(parseFloat((w / (h * h)).toFixed(1)));
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Calculator className="text-indigo-600" />
        <h3 className="text-lg font-semibold text-gray-900">BMI Calculator</h3>
      </div>
      <div className="space-y-3">
        <input type="number" placeholder="Weight (kg)" value={weight} onChange={(e) => setWeight(e.target.value)} className="w-full p-3 border rounded-xl" />
        <input type="number" placeholder="Height (cm)" value={height} onChange={(e) => setHeight(e.target.value)} className="w-full p-3 border rounded-xl" />
        <button onClick={calculateBMI} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-semibold">Calculate</button>
        {bmi !== null && <p className="text-center font-bold text-xl text-indigo-700">Your BMI: {bmi}</p>}
      </div>
    </div>
  );
};
