import React from 'react';
import { useFirebase } from './FirebaseProvider';

export const SubscriptionPage: React.FC = () => {
  const { user } = useFirebase();

  const handlePurchase = async (type: string, amount: number) => {
    if (!user) return;
    
    // Simulate payment process
    const response = await fetch('/api/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.uid, subscriptionType: type })
    });
    
    if (response.ok) {
        alert('Payment successful! Premium features activated.');
    } else {
        alert('Payment failed.');
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Upgrade to Premium</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h2 className="text-xl font-semibold mb-2">Study Premium</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-1">Monthly: ₹59 / $3.90</p>
                <p className="text-gray-600 dark:text-gray-400 mb-4">Yearly: ₹599 / $39</p>
                <div className="flex gap-2">
                    <button onClick={() => handlePurchase('study-monthly', 59)} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium">Monthly</button>
                    <button onClick={() => handlePurchase('study-yearly', 599)} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium">Yearly</button>
                </div>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h2 className="text-xl font-semibold mb-2">Health Premium</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">₹79/month</p>
                <button onClick={() => handlePurchase('health', 79)} className="w-full px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium">Purchase</button>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h2 className="text-xl font-semibold mb-2">Fitness Premium</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">₹79/month</p>
                <button onClick={() => handlePurchase('fitness', 79)} className="w-full px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium">Purchase</button>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h2 className="text-xl font-semibold mb-2">All-in-One Premium</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">₹199/month</p>
                <button onClick={() => handlePurchase('all', 199)} className="w-full px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium">Purchase</button>
            </div>
        </div>
    </div>
  );
};
