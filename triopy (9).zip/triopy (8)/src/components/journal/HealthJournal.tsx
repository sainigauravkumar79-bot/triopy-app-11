import React, { useState, useEffect } from 'react';
import { BookOpen, Send } from 'lucide-react';
import { collection, addDoc, query, orderBy, onSnapshot, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useFirebase } from '../FirebaseProvider';

interface JournalEntry {
  id: string;
  note: string;
  timestamp: Timestamp;
}

export const HealthJournal: React.FC = () => {
  const { user } = useFirebase();
  const [note, setNote] = useState('');
  const [entries, setEntries] = useState<JournalEntry[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'users', user.uid, 'journalEntries'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as JournalEntry)));
    });
    return unsubscribe;
  }, [user]);

  const addEntry = async () => {
    if (!user || !note.trim()) return;
    await addDoc(collection(db, 'users', user.uid, 'journalEntries'), {
      note,
      timestamp: Timestamp.now()
    });
    setNote('');
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <BookOpen className="text-pink-600" />
        <h3 className="text-lg font-semibold text-gray-900">Health Journal</h3>
      </div>
      <div className="flex gap-2 mb-4">
        <input 
          value={note} 
          onChange={e => setNote(e.target.value)}
          placeholder="How was your day?"
          className="flex-1 p-3 border rounded-xl"
        />
        <button onClick={addEntry} className="p-3 bg-pink-600 text-white rounded-xl"><Send size={20} /></button>
      </div>
      <div className="space-y-2 max-h-48 overflow-y-auto">
        {entries.map(entry => (
          <div key={entry.id} className="p-2 bg-gray-50 rounded-lg text-sm text-gray-700">
            {entry.note}
          </div>
        ))}
      </div>
    </div>
  );
};
