import React, { useState } from 'react';
import { Dumbbell } from 'lucide-react';

export const WorkoutTracker: React.FC = () => {
  const [workout, setWorkout] = useState('');

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Dumbbell className="text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900">Workout Tracker</h3>
      </div>
      <input 
        type="text" 
        placeholder="Enter workout (e.g. 30min running)" 
        value={workout} 
        onChange={(e) => setWorkout(e.target.value)} 
        className="w-full p-3 border rounded-xl mb-3"
      />
      <button className="w-full py-3 bg-purple-600 text-white rounded-xl font-semibold">Log Workout</button>
    </div>
  );
};
