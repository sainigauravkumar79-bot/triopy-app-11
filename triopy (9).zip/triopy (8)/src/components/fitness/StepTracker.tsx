import React, { useState } from 'react';
import { Footprints } from 'lucide-react';

export const StepTracker: React.FC = () => {
  const [steps, setSteps] = useState(0);

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3 mb-4">
        <Footprints className="text-orange-500" />
        <h3 className="text-lg font-semibold text-gray-900">Step Tracker</h3>
      </div>
      <div className="text-center mb-4">
        <p className="text-4xl font-bold text-orange-600">{steps}</p>
      </div>
      <button onClick={() => setSteps(s => s + 500)} className="w-full py-3 bg-orange-100 text-orange-700 rounded-xl font-semibold">+500 steps</button>
    </div>
  );
};
