import React from 'react';
import { WorkoutTracker } from './WorkoutTracker';
import { StepTracker } from './StepTracker';

export const FitnessModule: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <WorkoutTracker />
      <StepTracker />
    </div>
  );
};
