import React, { useEffect } from 'react';
import { doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useFirebase } from './FirebaseProvider';

export const SubscriptionManager: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useFirebase();

  useEffect(() => {
    if (!user) return;

    const initSubscription = async () => {
      const subRef = doc(db, 'users', user.uid, 'subscription', 'status');
      const snap = await getDoc(subRef);
      if (!snap.exists()) {
        await setDoc(subRef, {
          isPremium: true,
          trialStartDate: Timestamp.now(),
          subscriptionType: 'trial'
        });
      }
    };
    initSubscription();
  }, [user]);

  return <>{children}</>;
};
