import React, { useState } from 'react';
import { createUserWithEmailAndPassword, signInAnonymously } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';

interface SignUpProps {
  onBackToLogin: () => void;
}

export const SignUp: React.FC<SignUpProps> = ({ onBackToLogin }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // OTP States
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpMessage, setOtpMessage] = useState<string | null>(null);
  const [debugOtp, setDebugOtp] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    // Reset OTP verification state if the user changes the email
    setOtpSent(false);
    setOtpVerified(false);
    setOtpMessage(null);
    setDebugOtp(null);
  };

  const handleSendOtp = async () => {
    setError(null);
    setOtpMessage(null);
    if (!email || !email.includes('@')) {
      setError('Please enter a valid Gmail address first.');
      return;
    }
    setOtpLoading(true);
    try {
      const response = await fetch('/api/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to send verification code.');
      }
      setOtpSent(true);
      setOtpMessage(data.message || 'OTP sent successfully.');
      if (data.debugOtp) {
        setDebugOtp(data.debugOtp);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to send OTP.');
    } finally {
      setOtpLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setError(null);
    setOtpMessage(null);
    if (!otpCode || otpCode.trim().length !== 6) {
      setError('Please enter a valid 6-digit OTP code.');
      return;
    }
    setOtpLoading(true);
    try {
      const response = await fetch('/api/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: otpCode }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Invalid OTP code.');
      }
      setOtpVerified(true);
      setOtpMessage('Email verified successfully! You can now create your account.');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Verification failed.');
    } finally {
      setOtpLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) return setError('Name cannot be empty.');
    const ageNum = parseInt(age);
    if (isNaN(ageNum) || ageNum < 10 || ageNum > 100) return setError('Age must be between 10 and 100.');
    if (password.length < 6) return setError('Password must be at least 6 characters.');
    if (!otpVerified) return setError('Please verify your Gmail address with OTP first.');
    
    setLoading(true);
    try {
        // Create user with a chosen password
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Save user profile to Firestore under user.uid and email for safety and full compatibility
        const profileData = { name, age: ageNum, email, createdAt: new Date() };
        await setDoc(doc(db, 'users', user.uid), profileData);
        await setDoc(doc(db, 'users', email), profileData);
        
        // No alert & back redirection. Firebase will automatically take them straight to the dashboard!
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error creating account.');
    } finally {
      setLoading(false);
    }
  };

  const handleInstantCreate = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInAnonymously(auth);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Instant creation failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSignUp} className="space-y-4">
      <h1 className="text-3xl font-bold text-center text-indigo-700">TRIOPY</h1>
      <h2 className="text-2xl font-bold mb-6 text-gray-900 text-center">Create Your Account</h2>
      
      <input 
        type="text" 
        value={name} 
        onChange={(e) => setName(e.target.value)} 
        placeholder="Full Name" 
        required 
        className="w-full p-4 border border-gray-200 rounded-2xl" 
      />
      
      <input 
        type="number" 
        value={age} 
        onChange={(e) => setAge(e.target.value)} 
        placeholder="Age" 
        required 
        className="w-full p-4 border border-gray-200 rounded-2xl" 
      />
      
      <div className="space-y-2">
        <div className="flex gap-2">
          <input 
            type="email" 
            value={email} 
            onChange={handleEmailChange} 
            placeholder="Gmail Address" 
            required 
            disabled={otpVerified}
            className="flex-1 p-4 border border-gray-200 rounded-2xl disabled:bg-gray-100 disabled:text-gray-500" 
          />
          {!otpVerified && (
            <button 
              type="button" 
              onClick={handleSendOtp} 
              disabled={otpLoading || !email}
              className="px-4 bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold rounded-2xl hover:bg-indigo-100 transition-all text-sm whitespace-nowrap disabled:opacity-50 cursor-pointer"
            >
              {otpSent ? 'Resend' : 'Send OTP'}
            </button>
          )}
        </div>
        {otpVerified && (
          <p className="text-xs text-emerald-600 font-medium flex items-center gap-1 px-2">
            ✓ Gmail address verified
          </p>
        )}
      </div>

      {otpSent && !otpVerified && (
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
          <p className="text-xs text-gray-600">Please enter the 6-digit OTP sent to your email.</p>
          <div className="flex gap-2">
            <input 
              type="text" 
              maxLength={6}
              value={otpCode} 
              onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))} 
              placeholder="6-digit OTP" 
              className="flex-1 p-4 border border-gray-200 rounded-2xl text-center font-mono text-lg tracking-widest" 
            />
            <button 
              type="button" 
              onClick={handleVerifyOtp} 
              disabled={otpLoading || otpCode.length !== 6}
              className="px-6 bg-indigo-600 text-white font-semibold rounded-2xl hover:bg-indigo-700 transition-all text-sm disabled:opacity-50 cursor-pointer"
            >
              Verify
            </button>
          </div>

          {debugOtp && (
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs space-y-1">
              <span className="font-semibold">🛠️ Development Fallback:</span>
              <p>SMTP is not configured in `.env`. Since you are testing, we fetched the OTP for you directly:</p>
              <p className="font-mono font-bold text-sm text-center bg-white p-1 rounded border border-amber-300 select-all tracking-wider">{debugOtp}</p>
            </div>
          )}
        </div>
      )}

      <input 
        type="password" 
        value={password} 
        onChange={(e) => setPassword(e.target.value)} 
        placeholder="Password (min 6 chars)" 
        required 
        className="w-full p-4 border border-gray-200 rounded-2xl" 
      />

      <button 
        type="submit" 
        disabled={loading || !otpVerified} 
        className="w-full p-4 bg-indigo-600 text-white rounded-2xl font-semibold hover:bg-indigo-700 disabled:opacity-50 transition-all cursor-pointer"
      >
        {loading ? 'Creating...' : 'Create Account'}
      </button>

      <button 
        type="button" 
        onClick={handleInstantCreate} 
        disabled={loading} 
        className="w-full p-4 bg-emerald-600 text-white rounded-2xl font-semibold hover:bg-emerald-700 transition-all cursor-pointer"
      >
        Instant Guest Sign Up (Direct to Dashboard)
      </button>

      <button 
        type="button" 
        onClick={onBackToLogin} 
        className="w-full p-4 text-gray-600 font-medium hover:text-gray-800 transition-all cursor-pointer"
      >
        Back to Login
      </button>

      {otpMessage && <p className="text-indigo-600 text-sm text-center font-medium">{otpMessage}</p>}
      {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
    </form>
  );
};
