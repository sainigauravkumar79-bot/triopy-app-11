import React, { useState } from 'react';
import { signInWithEmailAndPassword, sendPasswordResetEmail, signInAnonymously, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../lib/firebase';

interface LoginProps {
  onSignUp: () => void;
}

export const Login: React.FC<LoginProps> = ({ onSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      // FirebaseProvider onAuthStateChanged will handle the login state transition automatically
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError('Please enter your email address first.');
      return;
    }
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      await sendPasswordResetEmail(auth, email);
      setMessage('Password reset email sent. Please check your inbox.');
    } catch (err: any) {
      setError(err.message || 'Error sending password reset email.');
    } finally {
      setLoading(false);
    }
  };

  const handleInstantLogin = async () => {
    setError(null);
    setMessage(null);
    setLoading(true);
    try {
      // Try demo credentials first
      try {
        await signInWithEmailAndPassword(auth, 'demo@triopy.com', 'password123');
      } catch (err: any) {
        if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
          try {
            await createUserWithEmailAndPassword(auth, 'demo@triopy.com', 'password123');
          } catch (createErr) {
            await signInAnonymously(auth);
          }
        } else {
          await signInAnonymously(auth);
        }
      }
    } catch (err: any) {
      console.error(err);
      setError('Instant Login failed. Try creating a manual account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold text-center text-indigo-700 tracking-wider">TRIOPY</h1>
      <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white text-center">Welcome Back</h2>
      
      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            placeholder="Email Address" 
            required 
            className="w-full p-4 border border-gray-200 rounded-2xl dark:bg-gray-800 dark:border-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" 
          />
        </div>
        <div>
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            placeholder="Password" 
            required 
            className="w-full p-4 border border-gray-200 rounded-2xl dark:bg-gray-800 dark:border-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500" 
          />
        </div>
        
        <button 
          type="submit" 
          disabled={loading} 
          className="w-full p-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-semibold transition-colors disabled:opacity-50"
        >
          {loading ? 'Logging in...' : 'Log In'}
        </button>

        <button 
          type="button" 
          onClick={handleInstantLogin}
          disabled={loading} 
          className="w-full p-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-semibold transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          Instant Login (Direct to Dashboard)
        </button>

        <div className="text-center">
          <button 
            type="button" 
            onClick={handleForgotPassword} 
            className="text-xs text-gray-500 hover:text-indigo-600 hover:underline"
          >
            Forgot Password?
          </button>
        </div>

        {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
        {message && <p className="text-green-500 text-sm text-center font-medium">{message}</p>}
      </form>

      <div className="border-t border-gray-100 dark:border-gray-800 pt-4 text-center text-sm text-gray-600 dark:text-gray-400">
        Don't have an account?{' '}
        <button onClick={onSignUp} className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline">
          Sign Up
        </button>
      </div>
    </div>
  );
};
