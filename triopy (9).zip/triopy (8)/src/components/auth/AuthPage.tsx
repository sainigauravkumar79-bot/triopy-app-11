import React, { useState } from 'react';
import { Login } from './Login';
import { SignUp } from './SignUp';

export const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [modal, setModal] = useState<'terms' | 'privacy' | null>(null);

  return (
    <div className="w-full max-w-sm p-8 bg-white rounded-3xl shadow-sm border border-gray-100">
      {isLogin ? (
        <Login onSignUp={() => setIsLogin(false)} />
      ) : (
        <SignUp onBackToLogin={() => setIsLogin(true)} />
      )}

      <div className="mt-6 text-center text-xs text-gray-500">
        <button onClick={() => setModal('terms')} className="hover:underline mr-2">Terms of Service</button>
        <button onClick={() => setModal('privacy')} className="hover:underline">Privacy Policy</button>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 rounded-2xl max-w-sm w-full">
            <h2 className="text-lg font-bold mb-4">{modal === 'terms' ? 'Terms of Service' : 'Privacy Policy'}</h2>
            <p className="text-sm text-gray-600 mb-6">Placeholder content for {modal === 'terms' ? 'Terms of Service' : 'Privacy Policy'}.</p>
            <button onClick={() => setModal(null)} className="w-full p-2 bg-gray-200 rounded-lg">Close</button>
          </div>
        </div>
      )}
    </div>
  );
};
