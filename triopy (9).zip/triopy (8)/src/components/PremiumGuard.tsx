import React from 'react';
import { useSubscription } from '../hooks/useSubscription';

export const PremiumGuard: React.FC<{ children: React.ReactNode, requiredType?: 'study' | 'health' | 'fitness' }> = ({ children, requiredType }) => {
  const { subscription, loading } = useSubscription();

  if (loading) return <div className="p-4">Loading...</div>;
  
  const isAuthorized = subscription?.isPremium && (
    !requiredType ||
    subscription.subscriptionType === 'all' ||
    subscription.subscriptionType?.startsWith(requiredType)
  );

  if (!isAuthorized) {
    return (
      <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl border shadow-sm text-center">
        <h2 className="text-xl font-bold mb-4">Premium Required</h2>
        <p className="mb-6">Upgrade your subscription to access {requiredType || 'premium'} features.</p>
        <button className="px-6 py-2 bg-indigo-600 text-white rounded-xl">View Plans</button>
      </div>
    );
  }
  
  return <>{children}</>;
};
