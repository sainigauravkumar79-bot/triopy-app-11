import React, { useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export const PaymentSettings: React.FC = () => {
  const [keyId, setKeyId] = useState('');
  const [keySecret, setKeySecret] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    const fetchConfig = async () => {
      const snap = await getDoc(doc(db, 'config', 'payment'));
      if (snap.exists()) {
        const data = snap.data();
        setKeyId(data.keyId);
        setKeySecret(data.keySecret);
      }
    };
    fetchConfig();
  }, []);

  const saveConfig = async () => {
    await setDoc(doc(db, 'config', 'payment'), { keyId, keySecret });
    setStatus('Configuration saved successfully!');
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
      <h2 className="text-xl font-bold mb-6">Payment Settings</h2>
      <div className="space-y-4">
        <input 
          value={keyId} onChange={(e) => setKeyId(e.target.value)}
          placeholder="Razorpay Key ID" className="w-full p-3 rounded-xl border"
        />
        <input 
          type="password"
          value={keySecret} onChange={(e) => setKeySecret(e.target.value)}
          placeholder="Razorpay Key Secret" className="w-full p-3 rounded-xl border"
        />
        <button onClick={saveConfig} className="px-6 py-2 bg-indigo-600 text-white rounded-xl">Save Configuration</button>
        {status && <p className="text-green-600">{status}</p>}
      </div>
    </div>
  );
};
