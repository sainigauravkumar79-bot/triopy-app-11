export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  premiumStatus: boolean;
  premiumType?: 'monthly' | 'yearly';
  currency: 'INR' | 'USD';
  healthScore: number;
  studyStreak: number;
  level: number;
}

export interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
}

export interface Workout {
  id: string;
  name: string;
  duration: number; // minutes
  type: 'cardio' | 'strength' | 'yoga' | 'hiit';
}

export interface Habit {
  id: string;
  userId: string;
  name: string;
  category: 'study' | 'fitness';
  createdAt: any;
  completedDates: string[]; // Array of YYYY-MM-DD strings
  streak: number;
}

export interface Hydration {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  glasses: number;
}

