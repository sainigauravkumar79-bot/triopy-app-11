/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import { isSignInWithEmailLink, signInWithEmailLink } from 'firebase/auth';
import { auth } from './lib/firebase';
import { useFirebase } from './components/FirebaseProvider';
import { Dashboard } from './components/Dashboard';
import { AuthPage } from './components/auth/AuthPage';
import { ThemeProvider } from './context/ThemeContext';
import { SubscriptionManager } from './components/SubscriptionManager';

export default function App() {
  const { user, loading } = useFirebase();

  useEffect(() => {
    if (isSignInWithEmailLink(auth, window.location.href)) {
      let email = window.localStorage.getItem('emailForSignIn');
      if (!email) {
        email = window.prompt('Please provide your email to complete sign in');
      }
      if (email) {
        signInWithEmailLink(auth, email, window.location.href)
          .then(() => window.localStorage.removeItem('emailForSignIn'))
          .catch((err) => console.error('Error signing in with link', err));
      }
    }
  }, []);

  if (loading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  if (!user) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <AuthPage />
      </div>
    );
  }

  return (
    <ThemeProvider>
      <SubscriptionManager>
        <Dashboard />
      </SubscriptionManager>
    </ThemeProvider>
  );
}
