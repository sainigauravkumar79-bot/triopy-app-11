import { useState, useEffect } from 'react';
import { collection, query, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useFirebase } from '../components/FirebaseProvider';
import { Habit } from '../types';

export const useHabits = () => {
  const { user } = useFirebase();
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const habitsRef = collection(db, 'users', user.uid, 'habits');
    const q = query(habitsRef);

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedHabits: Habit[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        fetchedHabits.push({
          id: docSnap.id,
          userId: user.uid,
          name: data.name || '',
          category: data.category || 'study',
          createdAt: data.createdAt,
          completedDates: data.completedDates || [],
          streak: data.streak || 0,
        });
      });
      setHabits(fetchedHabits);
      setLoading(false);
    });

    return unsubscribe;
  }, [user]);

  return { habits, loading };
};
