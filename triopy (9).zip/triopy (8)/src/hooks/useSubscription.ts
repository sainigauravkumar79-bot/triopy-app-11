import { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useFirebase } from '../components/FirebaseProvider';

interface Subscription {
  isPremium: boolean;
  trialStartDate?: any;
  subscriptionType?: string;
  subscriptionEndDate?: any;
}

export const useSubscription = () => {
  const { user } = useFirebase();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const unsub = onSnapshot(doc(db, 'users', user.uid, 'subscription', 'status'), (snap) => {
      if (snap.exists()) {
        setSubscription(snap.data() as Subscription);
      } else {
        setSubscription({ isPremium: false });
      }
      setLoading(false);
    });
    return unsub;
  }, [user]);

  return { subscription, loading };
};
